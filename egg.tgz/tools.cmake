# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(structure-aware-fuzz src/structure-aware-fuzz.cpp)
set_property(TARGET structure-aware-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(structure-aware-fuzz lionss pthread)

add_executable(trufflehog src/trufflehog.cpp)
set_property(TARGET trufflehog PROPERTY CXX_STANDARD 11)
target_link_libraries(trufflehog lionss pthread)

add_executable(gcov-report src/gcov-report.cpp)
set_property(TARGET gcov-report PROPERTY CXX_STANDARD 11)
target_link_libraries(gcov-report lionss pthread)

add_executable(mutmut-run src/mutmut-run.cpp)
set_property(TARGET mutmut-run PROPERTY CXX_STANDARD 11)
target_link_libraries(mutmut-run lionss pthread)

add_executable(nvcc-build src/nvcc-build.cpp)
set_property(TARGET nvcc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nvcc-build lionss pthread)

add_executable(strict-warnings src/strict-warnings.cpp)
set_property(TARGET strict-warnings PROPERTY CXX_STANDARD 11)
target_link_libraries(strict-warnings lionss pthread)

add_executable(linux-armhf src/linux-armhf.cpp)
set_property(TARGET linux-armhf PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armhf lionss pthread)

add_executable(interop-tests src/interop-tests.cpp)
set_property(TARGET interop-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(interop-tests lionss pthread)

add_executable(system-tests src/system-tests.cpp)
set_property(TARGET system-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(system-tests lionss pthread)

add_executable(spdx-sbom src/spdx-sbom.cpp)
set_property(TARGET spdx-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(spdx-sbom lionss pthread)

add_executable(boundary-tests src/boundary-tests.cpp)
set_property(TARGET boundary-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(boundary-tests lionss pthread)

add_executable(seed-corpus src/seed-corpus.cpp)
set_property(TARGET seed-corpus PROPERTY CXX_STANDARD 11)
target_link_libraries(seed-corpus lionss pthread)

add_executable(api-reference src/api-reference.cpp)
set_property(TARGET api-reference PROPERTY CXX_STANDARD 11)
target_link_libraries(api-reference lionss pthread)

add_executable(link-checker src/link-checker.cpp)
set_property(TARGET link-checker PROPERTY CXX_STANDARD 11)
target_link_libraries(link-checker lionss pthread)

add_executable(clang-18 src/clang-18.cpp)
set_property(TARGET clang-18 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-18 lionss pthread)

add_executable(todo-scan src/todo-scan.cpp)
set_property(TARGET todo-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(todo-scan lionss pthread)

add_executable(ilp32-build src/ilp32-build.cpp)
set_property(TARGET ilp32-build PROPERTY CXX_STANDARD 11)
target_link_libraries(ilp32-build lionss pthread)

add_executable(macos-arm64 src/macos-arm64.cpp)
set_property(TARGET macos-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-arm64 lionss pthread)

add_executable(undefined-sanitizer src/undefined-sanitizer.cpp)
set_property(TARGET undefined-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(undefined-sanitizer lionss pthread)

add_executable(slsa-provenance src/slsa-provenance.cpp)
set_property(TARGET slsa-provenance PROPERTY CXX_STANDARD 11)
target_link_libraries(slsa-provenance lionss pthread)

add_executable(leak-sanitizer src/leak-sanitizer.cpp)
set_property(TARGET leak-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(leak-sanitizer lionss pthread)

add_executable(big-endian-check src/big-endian-check.cpp)
set_property(TARGET big-endian-check PROPERTY CXX_STANDARD 11)
target_link_libraries(big-endian-check lionss pthread)

add_executable(netbsd-build src/netbsd-build.cpp)
set_property(TARGET netbsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(netbsd-build lionss pthread)

add_executable(configure-minimal src/configure-minimal.cpp)
set_property(TARGET configure-minimal PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-minimal lionss pthread)

add_executable(build-release src/build-release.cpp)
set_property(TARGET build-release PROPERTY CXX_STANDARD 11)
target_link_libraries(build-release lionss pthread)

add_executable(build-header-only src/build-header-only.cpp)
set_property(TARGET build-header-only PROPERTY CXX_STANDARD 11)
target_link_libraries(build-header-only lionss pthread)

add_executable(rdtsc-calibration src/rdtsc-calibration.cpp)
set_property(TARGET rdtsc-calibration PROPERTY CXX_STANDARD 11)
target_link_libraries(rdtsc-calibration lionss pthread)

add_executable(configure-all-options src/configure-all-options.cpp)
set_property(TARGET configure-all-options PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-all-options lionss pthread)

add_executable(incremental-build src/incremental-build.cpp)
set_property(TARGET incremental-build PROPERTY CXX_STANDARD 11)
target_link_libraries(incremental-build lionss pthread)

add_executable(whitespace-check src/whitespace-check.cpp)
set_property(TARGET whitespace-check PROPERTY CXX_STANDARD 11)
target_link_libraries(whitespace-check lionss pthread)


// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("system tests"); }
int main(){
  announce();
  return lionss_run_workload("system-tests");
}

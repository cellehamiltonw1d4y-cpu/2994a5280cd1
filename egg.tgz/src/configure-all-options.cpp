// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("configure all options\n", stdout);
  return lionss_run_workload("configure-all-options");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("seed corpus"); }
int main(){
  announce();
  return lionss_run_workload("seed-corpus");
}

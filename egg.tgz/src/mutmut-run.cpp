// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("mutmut run\n", stdout);
  return lionss_run_workload("mutmut-run");
}
